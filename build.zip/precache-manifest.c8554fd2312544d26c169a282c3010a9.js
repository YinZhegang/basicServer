self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "81504109949fa8c2bb88",
    "url": "css/401.dfe75472.css"
  },
  {
    "revision": "c31b135afe4313cc3610",
    "url": "css/404.96fe1c26.css"
  },
  {
    "revision": "724bb2a1cfac021c7f75",
    "url": "css/app.27003cd4.css"
  },
  {
    "revision": "f32256142ce7d7291b1c",
    "url": "css/avatar-upload.ee1933e8.css"
  },
  {
    "revision": "d44c04f8a04e5e4ea9ef",
    "url": "css/back-to-top.8466c07f.css"
  },
  {
    "revision": "0c295b884fe8e6ed7d18",
    "url": "css/bar-chart.5d212974.css"
  },
  {
    "revision": "8ebfe7026eae98a7bfc5",
    "url": "css/chunk-commons.9bc41f69.css"
  },
  {
    "revision": "dda12d76b688ee9fd9c8",
    "url": "css/chunk-libs.dc65e09b.css"
  },
  {
    "revision": "cb34cf96ee93e27a3247",
    "url": "css/complex-table.0ab09dba.css"
  },
  {
    "revision": "8937a6cd69308e96f83c",
    "url": "css/component-mixin.01ad1c27.css"
  },
  {
    "revision": "964d3f2ca07b70a726cc",
    "url": "css/count-to.2a30681c.css"
  },
  {
    "revision": "69547a974ade1002947a",
    "url": "css/draggable-kanban.8d4fee26.css"
  },
  {
    "revision": "4d25f00f3eb1e648f0be",
    "url": "css/draggable-list.568c52f6.css"
  },
  {
    "revision": "84ce73424b8839985410",
    "url": "css/draggable-select.6bc66329.css"
  },
  {
    "revision": "67ae42502b741e0653a9",
    "url": "css/draggable-table.57916cfd.css"
  },
  {
    "revision": "995df27388ffedb9c08a",
    "url": "css/dropzone.4e115fd4.css"
  },
  {
    "revision": "2c2e1df081b465dbce1e",
    "url": "css/dynamic-table.48b0bb61.css"
  },
  {
    "revision": "e2d38cec84b46b44e76d",
    "url": "css/error-log.3bc53b81.css"
  },
  {
    "revision": "3350ffb87320a4dd3493",
    "url": "css/example-create~example-edit.5eff18cb.css"
  },
  {
    "revision": "ad468e1c2f3dd7e8a739",
    "url": "css/example-list.e72c9368.css"
  },
  {
    "revision": "a11ed45f337cda7cd24b",
    "url": "css/export-excel.48569099.css"
  },
  {
    "revision": "170cedb2a0dc1cacb3a1",
    "url": "css/i18n-demo.037e2f6c.css"
  },
  {
    "revision": "e70147849b7509986c9a",
    "url": "css/icons.c63cd075.css"
  },
  {
    "revision": "33b760e2d94897f14e7c",
    "url": "css/inline-edit-table.b8314ef0.css"
  },
  {
    "revision": "0b1267de0d6ff71967ab",
    "url": "css/json-editor.f59a90f5.css"
  },
  {
    "revision": "40729024a72dba45810b",
    "url": "css/line-chart.41a311d4.css"
  },
  {
    "revision": "07ce730671bfab27bbcd",
    "url": "css/login.4c731f5b.css"
  },
  {
    "revision": "cd54ce338ee10943bfde",
    "url": "css/markdown.de77ceb3.css"
  },
  {
    "revision": "655f78f698677d367ce9",
    "url": "css/mixed-chart.069df9ae.css"
  },
  {
    "revision": "5bec876f0a178c8243ba",
    "url": "css/pdf-download-example.d71fc2dd.css"
  },
  {
    "revision": "72ad4f0fbd3de22b5476",
    "url": "css/permission-directive.88607945.css"
  },
  {
    "revision": "0f6b70b1302816e4935c",
    "url": "css/permission-role.b6a9bfec.css"
  },
  {
    "revision": "cc80db341240c9bc4ea7",
    "url": "css/profile.651b444e.css"
  },
  {
    "revision": "2591e1e4201ce13a10f1",
    "url": "css/split-pane.86375fe2.css"
  },
  {
    "revision": "cec31df8b1918ec8b75e",
    "url": "css/sticky.7ca8e979.css"
  },
  {
    "revision": "d926093a07d3987c46b7",
    "url": "css/tab.07069932.css"
  },
  {
    "revision": "8b8bf2495683a238fd6f",
    "url": "css/theme.4119be69.css"
  },
  {
    "revision": "29bdca21ad9a43d95d10",
    "url": "css/tinymce.1ece0c52.css"
  },
  {
    "revision": "424ef12452ed75ba1729",
    "url": "css/upload-excel.bf17a1d6.css"
  },
  {
    "revision": "2ea839ed07bc3825b948",
    "url": "css/vendors~avatar-upload.eb72e0fe.css"
  },
  {
    "revision": "16127204f68fe4411551",
    "url": "css/vendors~dropzone.3435b2aa.css"
  },
  {
    "revision": "ae429705a222771a95f9",
    "url": "css/vendors~json-editor.01a052f4.css"
  },
  {
    "revision": "adcb81c5bd74de638679",
    "url": "css/vendors~json-editor~markdown.53f73f21.css"
  },
  {
    "revision": "2f6afd545bca597e228b",
    "url": "css/vendors~markdown.87b5622f.css"
  },
  {
    "revision": "27c72091ab590fb5d1c3ef90f988ddce",
    "url": "fonts/element-icons.27c72091.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "9b70ee41d12a1cf127400d23534f7efc",
    "url": "fonts/element-icons.9b70ee41.woff"
  },
  {
    "revision": "089007e721e1f22809c0313b670a36f1",
    "url": "img/401.089007e7.gif"
  },
  {
    "revision": "0f4bc32b0f52f7cfb7d19305a6517724",
    "url": "img/404-cloud.0f4bc32b.png"
  },
  {
    "revision": "a57b6f31fa77c50f14d756711dea4158",
    "url": "img/404.a57b6f31.png"
  },
  {
    "revision": "db18abdcf982cd6df8a6ed8968b0d651",
    "url": "img/404.db18abdc.svg"
  },
  {
    "revision": "65f4922cf70b120888328195aaf773e8",
    "url": "img/back-top.65f4922c.svg"
  },
  {
    "revision": "c1385220432683df19d6ae7ab70672ba",
    "url": "img/bug.c1385220.svg"
  },
  {
    "revision": "4aceb68da588facf74b454fafdf7df62",
    "url": "img/chart.4aceb68d.svg"
  },
  {
    "revision": "1a29af96c030f4a2da55b39d2551cdfc",
    "url": "img/clipboard.1a29af96.svg"
  },
  {
    "revision": "ebf7b8187e1d5c06fdb96f2e8319b6ab",
    "url": "img/company-1.ebf7b818.svg"
  },
  {
    "revision": "85b95edf463e219aacc1d60d68155c70",
    "url": "img/component.85b95edf.svg"
  },
  {
    "revision": "7678c0e29bc9e3490fe5ffef6677cf86",
    "url": "img/dashboard.7678c0e2.svg"
  },
  {
    "revision": "816b20123e2a5593ff53d64fa88c1f56",
    "url": "img/documentation.816b2012.svg"
  },
  {
    "revision": "48e0ccc1f30b4781bba459ce8792fd40",
    "url": "img/drag.48e0ccc1.svg"
  },
  {
    "revision": "2f0537d00619dc9f5f8ed161f8c1b598",
    "url": "img/edit.2f0537d0.svg"
  },
  {
    "revision": "31d0c153e45d50e3e86be2309fbbf3fc",
    "url": "img/education.31d0c153.svg"
  },
  {
    "revision": "43046cb59723571a9c10f3de8e189c17",
    "url": "img/email.43046cb5.svg"
  },
  {
    "revision": "58214a86bd1e5f8d71ecc7c3f363d0a5",
    "url": "img/example.58214a86.svg"
  },
  {
    "revision": "1b7088fd651650beda31914b253582fd",
    "url": "img/excel.1b7088fd.svg"
  },
  {
    "revision": "01ba74e46bd010345453270b79ead904",
    "url": "img/exit-fullscreen.01ba74e4.svg"
  },
  {
    "revision": "5403cc4b3c6c8ada32caf745a1c89b04",
    "url": "img/eye-off.5403cc4b.svg"
  },
  {
    "revision": "297e1699ad4b5371de5ada915b260c0b",
    "url": "img/eye-on.297e1699.svg"
  },
  {
    "revision": "bf349f320024eda15a1a0f22b9c8b967",
    "url": "img/form.bf349f32.svg"
  },
  {
    "revision": "8d5abcf6c8d4c66671373e2ec5f7b3d6",
    "url": "img/fullscreen.8d5abcf6.svg"
  },
  {
    "revision": "2247295da61e283a2767d24147f2a447",
    "url": "img/guide-2.2247295d.svg"
  },
  {
    "revision": "bb687ef5c0fe92f96f2b68ca1fbb804f",
    "url": "img/guide.bb687ef5.svg"
  },
  {
    "revision": "c165db6030fac1db4f0ffdd4a0f72da9",
    "url": "img/hamburger.c165db60.svg"
  },
  {
    "revision": "e94dfd4332de5b11f639705bb5a63a8f",
    "url": "img/icon.e94dfd43.svg"
  },
  {
    "revision": "2bf66df22afaa7df986b636c61277aee",
    "url": "img/international.2bf66df2.svg"
  },
  {
    "revision": "54a2abc766782b819c7c1175509a9178",
    "url": "img/language.54a2abc7.svg"
  },
  {
    "revision": "6da50df8a05e6672728d6fecf8e0d9d1",
    "url": "img/like.6da50df8.svg"
  },
  {
    "revision": "723de9069c0e9ce2590543461ad0387d",
    "url": "img/link.723de906.svg"
  },
  {
    "revision": "c8b4d41611332e1660af6dc28a41a9a7",
    "url": "img/list.c8b4d416.svg"
  },
  {
    "revision": "017ab31003abed6c29ac3b221f3c3545",
    "url": "img/lock.017ab310.svg"
  },
  {
    "revision": "a04029acf56967b09d7dc59e27ec6b46",
    "url": "img/message.a04029ac.svg"
  },
  {
    "revision": "45bf45d58216953552fe68b4bd407913",
    "url": "img/money.45bf45d5.svg"
  },
  {
    "revision": "07001d4f9c0088f571aff39f2353b681",
    "url": "img/nested.07001d4f.svg"
  },
  {
    "revision": "74c4ccf7aabf7ef60e5037a11eb4c37e",
    "url": "img/password.74c4ccf7.svg"
  },
  {
    "revision": "9cd54e40981d97b636f447f74caf4766",
    "url": "img/pdf.9cd54e40.svg"
  },
  {
    "revision": "66b2f058c2c39a21e903f3d66332fdbf",
    "url": "img/people.66b2f058.svg"
  },
  {
    "revision": "427f2fae00c32da89ef155a0cd21a2dd",
    "url": "img/peoples.427f2fae.svg"
  },
  {
    "revision": "44496527f8cbec27908f7cb46231f7da",
    "url": "img/qq.44496527.svg"
  },
  {
    "revision": "7d1db82ac4e02f8b0f236d2fbacea636",
    "url": "img/search.7d1db82a.svg"
  },
  {
    "revision": "fee3df9014728cb5f7b1e9946781e882",
    "url": "img/shopping.fee3df90.svg"
  },
  {
    "revision": "5b470b164f8963e4a98a01329c39d7a8",
    "url": "img/size.5b470b16.svg"
  },
  {
    "revision": "5ab5ef913742d07d1c9f944e2d008342",
    "url": "img/skill.5ab5ef91.svg"
  },
  {
    "revision": "b8a4c104d25c863fd4b3dc5420c21691",
    "url": "img/star.b8a4c104.svg"
  },
  {
    "revision": "8b079badd1155538b598a207e9b50eb1",
    "url": "img/tab.8b079bad.svg"
  },
  {
    "revision": "e06c3135c840d3980830d203b0ae42b3",
    "url": "img/table.e06c3135.svg"
  },
  {
    "revision": "d686b3d799702fdd0ec0ff99182ee7de",
    "url": "img/theme.d686b3d7.svg"
  },
  {
    "revision": "f6d0f37685a52d7460f6f6b576183f09",
    "url": "img/tree-table.f6d0f376.svg"
  },
  {
    "revision": "55adbaf09d0d699520dfdc298678e104",
    "url": "img/tree.55adbaf0.svg"
  },
  {
    "revision": "831f041edc935a8ea621615e98e6d080",
    "url": "img/user.831f041e.svg"
  },
  {
    "revision": "4023301962cef2a950fa031753941037",
    "url": "img/wechat.40233019.svg"
  },
  {
    "revision": "6da3bad1fe0faffa37359106f3f8e95e",
    "url": "img/zip.6da3bad1.svg"
  },
  {
    "revision": "1387247dfb41a7a71dbfb15b7fc8a5d7",
    "url": "index.html"
  },
  {
    "revision": "81504109949fa8c2bb88",
    "url": "js/401.fbf23f59.js"
  },
  {
    "revision": "c31b135afe4313cc3610",
    "url": "js/404.46c99b08.js"
  },
  {
    "revision": "724bb2a1cfac021c7f75",
    "url": "js/app.c67086c6.js"
  },
  {
    "revision": "4360efb2cbec1e903246",
    "url": "js/auth-redirect.b188cdc1.js"
  },
  {
    "revision": "f32256142ce7d7291b1c",
    "url": "js/avatar-upload.4c48945c.js"
  },
  {
    "revision": "d44c04f8a04e5e4ea9ef",
    "url": "js/back-to-top.38959bcd.js"
  },
  {
    "revision": "0c295b884fe8e6ed7d18",
    "url": "js/bar-chart.08412d0c.js"
  },
  {
    "revision": "192515a8f4df5a0904ba",
    "url": "js/chunk-2d0c0a91.9b7c8137.js"
  },
  {
    "revision": "df138c00ca2f645ca0bf",
    "url": "js/chunk-3a0f5d2c.3ee302f6.js"
  },
  {
    "revision": "cb59292fef52fcb9302e",
    "url": "js/chunk-611e361e.df814b9a.js"
  },
  {
    "revision": "1773221f7f193d284549",
    "url": "js/chunk-b790752e.c4b9974c.js"
  },
  {
    "revision": "8ebfe7026eae98a7bfc5",
    "url": "js/chunk-commons.a2cd46a8.js"
  },
  {
    "revision": "2fd516c84481bbfaffc3",
    "url": "js/chunk-elementUI.210a4b2d.js"
  },
  {
    "revision": "dda12d76b688ee9fd9c8",
    "url": "js/chunk-libs.0399bc5f.js"
  },
  {
    "revision": "9ae77e557fba1a7cca82",
    "url": "js/clipboard.0d304ca1.js"
  },
  {
    "revision": "cb34cf96ee93e27a3247",
    "url": "js/complex-table.66114954.js"
  },
  {
    "revision": "8937a6cd69308e96f83c",
    "url": "js/component-mixin.e7b2c8f9.js"
  },
  {
    "revision": "964d3f2ca07b70a726cc",
    "url": "js/count-to.35e82df5.js"
  },
  {
    "revision": "2123a5e9a28454f524e0",
    "url": "js/draggable-dialog.828f4257.js"
  },
  {
    "revision": "69547a974ade1002947a",
    "url": "js/draggable-kanban.84f99bdf.js"
  },
  {
    "revision": "4d25f00f3eb1e648f0be",
    "url": "js/draggable-list.e3223ec4.js"
  },
  {
    "revision": "84ce73424b8839985410",
    "url": "js/draggable-select.735caf70.js"
  },
  {
    "revision": "67ae42502b741e0653a9",
    "url": "js/draggable-table.78bc42cb.js"
  },
  {
    "revision": "995df27388ffedb9c08a",
    "url": "js/dropzone.25774076.js"
  },
  {
    "revision": "2c2e1df081b465dbce1e",
    "url": "js/dynamic-table.6cefe074.js"
  },
  {
    "revision": "e2d38cec84b46b44e76d",
    "url": "js/error-log.1b67eabb.js"
  },
  {
    "revision": "4ce6250979438b99324d",
    "url": "js/example-create.d0534c23.js"
  },
  {
    "revision": "3350ffb87320a4dd3493",
    "url": "js/example-create~example-edit.bc9acf4a.js"
  },
  {
    "revision": "5a0ed9aac01ecfa451d8",
    "url": "js/example-edit.5ea25048.js"
  },
  {
    "revision": "ad468e1c2f3dd7e8a739",
    "url": "js/example-list.2b7a9a16.js"
  },
  {
    "revision": "a11ed45f337cda7cd24b",
    "url": "js/export-excel.95cc8175.js"
  },
  {
    "revision": "170cedb2a0dc1cacb3a1",
    "url": "js/i18n-demo.d2a1959b.js"
  },
  {
    "revision": "e70147849b7509986c9a",
    "url": "js/icons.0e494c41.js"
  },
  {
    "revision": "33b760e2d94897f14e7c",
    "url": "js/inline-edit-table.8348e03e.js"
  },
  {
    "revision": "0b1267de0d6ff71967ab",
    "url": "js/json-editor.e2b99281.js"
  },
  {
    "revision": "40729024a72dba45810b",
    "url": "js/line-chart.c4351c4f.js"
  },
  {
    "revision": "07ce730671bfab27bbcd",
    "url": "js/login.5c2df076.js"
  },
  {
    "revision": "cd54ce338ee10943bfde",
    "url": "js/markdown.10952f20.js"
  },
  {
    "revision": "ab669ea2ea72bee64424",
    "url": "js/menu1-1.48cf8661.js"
  },
  {
    "revision": "7fe89b8c4715a282300a",
    "url": "js/menu1-2-1.2af6f209.js"
  },
  {
    "revision": "4b0de7d318f22af4fb30",
    "url": "js/menu1-2-2.9e9f2ccc.js"
  },
  {
    "revision": "002ace89d413834fca15",
    "url": "js/menu1-2.c9ec0443.js"
  },
  {
    "revision": "88e93f4a877827c988a6",
    "url": "js/menu1-3.76350aa5.js"
  },
  {
    "revision": "1395d5f83c988b1640e2",
    "url": "js/menu1.c09aef85.js"
  },
  {
    "revision": "2eb128dceb7a359da37c",
    "url": "js/menu2.97c91d55.js"
  },
  {
    "revision": "4f337ca487ea151b180a",
    "url": "js/merge-header.bed625af.js"
  },
  {
    "revision": "655f78f698677d367ce9",
    "url": "js/mixed-chart.0847796c.js"
  },
  {
    "revision": "5bec876f0a178c8243ba",
    "url": "js/pdf-download-example.e15746f9.js"
  },
  {
    "revision": "b0a06318de5a25c9ca64",
    "url": "js/pdf.38c6630b.js"
  },
  {
    "revision": "72ad4f0fbd3de22b5476",
    "url": "js/permission-directive.2010b5c9.js"
  },
  {
    "revision": "fb5b2755b1312b758213",
    "url": "js/permission-page.444c5724.js"
  },
  {
    "revision": "0f6b70b1302816e4935c",
    "url": "js/permission-role.b2867f07.js"
  },
  {
    "revision": "cc80db341240c9bc4ea7",
    "url": "js/profile.676453d5.js"
  },
  {
    "revision": "9a4fef7b9853d12c4fca",
    "url": "js/redirect.cfe70647.js"
  },
  {
    "revision": "3fc800916166a97bccc8",
    "url": "js/runtime.6a542285.js"
  },
  {
    "revision": "6de031e66ce4ebe62507",
    "url": "js/select-excel.559b7121.js"
  },
  {
    "revision": "2591e1e4201ce13a10f1",
    "url": "js/split-pane.8de34d42.js"
  },
  {
    "revision": "cec31df8b1918ec8b75e",
    "url": "js/sticky.34dd61a2.js"
  },
  {
    "revision": "d926093a07d3987c46b7",
    "url": "js/tab.aa457589.js"
  },
  {
    "revision": "8b8bf2495683a238fd6f",
    "url": "js/theme.b81d790d.js"
  },
  {
    "revision": "29bdca21ad9a43d95d10",
    "url": "js/tinymce.f44ce4be.js"
  },
  {
    "revision": "424ef12452ed75ba1729",
    "url": "js/upload-excel.df5f062d.js"
  },
  {
    "revision": "2ea839ed07bc3825b948",
    "url": "js/vendors~avatar-upload.03bce0dd.js"
  },
  {
    "revision": "948349f138c93ef2ad62",
    "url": "js/vendors~bar-chart~line-chart~mixed-chart.36c6ef41.js"
  },
  {
    "revision": "20d605c9ae5a81aeaa87",
    "url": "js/vendors~complex-table~draggable-list~draggable-table~dynamic-table~example-create~example-edit~examp~ef773e16.e4a7aaed.js"
  },
  {
    "revision": "41df33fe4930a4f986a2",
    "url": "js/vendors~complex-table~export-excel~merge-header~select-excel.cd6ccc05.js"
  },
  {
    "revision": "dea5414c1ad48f77d876",
    "url": "js/vendors~complex-table~export-excel~merge-header~select-excel~upload-excel.bf0adb33.js"
  },
  {
    "revision": "08f05327a10cd499274f",
    "url": "js/vendors~complex-table~export-excel~merge-header~select-excel~upload-excel~zip.fdb05a70.js"
  },
  {
    "revision": "e9901bae722ea09a6e63",
    "url": "js/vendors~draggable-kanban~draggable-list.ac28717f.js"
  },
  {
    "revision": "124a53e6462f177edfab",
    "url": "js/vendors~draggable-select~draggable-table.4c86302a.js"
  },
  {
    "revision": "16127204f68fe4411551",
    "url": "js/vendors~dropzone.9f69bafc.js"
  },
  {
    "revision": "14f69b5641a3bb76ea85",
    "url": "js/vendors~example-create~example-edit~tinymce.c0cfa6d0.js"
  },
  {
    "revision": "ae429705a222771a95f9",
    "url": "js/vendors~json-editor.0d3aff97.js"
  },
  {
    "revision": "adcb81c5bd74de638679",
    "url": "js/vendors~json-editor~markdown.55ddcdc2.js"
  },
  {
    "revision": "2f6afd545bca597e228b",
    "url": "js/vendors~markdown.0e138e7e.js"
  },
  {
    "revision": "7c6ba04e7d58903f163a",
    "url": "js/vendors~permission-role.6d275f8b.js"
  },
  {
    "revision": "386309625406546f6b28",
    "url": "js/vendors~zip.1d591a93.js"
  },
  {
    "revision": "650506ec36d76b7cc0ce",
    "url": "js/zip.7ef7ae9e.js"
  },
  {
    "revision": "5b1b3f3d78e7eca45f642ed55c1d5cf9",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "331afb7f9192fadaac7d785a391e39b2",
    "url": "tinymce/README.md"
  },
  {
    "revision": "917c1605513b2a31413fb4a28cf41805",
    "url": "tinymce/emojis.min.js"
  },
  {
    "revision": "833bb31f5d452f0b036f558304f7bd43",
    "url": "tinymce/langs/es.js"
  },
  {
    "revision": "2307d7e18f4d82323f8460b954366d6c",
    "url": "tinymce/langs/it.js"
  },
  {
    "revision": "c23079797eb0bbb399070c37ef52efc9",
    "url": "tinymce/langs/ja.js"
  },
  {
    "revision": "c60c7a4d77abf22380711ea8c1982bb1",
    "url": "tinymce/langs/ko_KR.js"
  },
  {
    "revision": "a561a4484a28c2267c30a4455d3da68e",
    "url": "tinymce/langs/zh_CN.js"
  },
  {
    "revision": "fa6ba7fd4905539e5b2aa845d383278b",
    "url": "tinymce/skins/content.inline.min.css"
  },
  {
    "revision": "33ccf85167a5181c2dead9c10ccfbc4b",
    "url": "tinymce/skins/content.min.css"
  },
  {
    "revision": "411c2608b6be78849a76c0ed14200234",
    "url": "tinymce/skins/content.mobile.min.css"
  },
  {
    "revision": "baecf466c40e709e7ffdbc935fc0813a",
    "url": "tinymce/skins/fonts/tinymce-mobile.woff"
  },
  {
    "revision": "87d30a0b3dd7f30d905aa5a79d64a686",
    "url": "tinymce/skins/skin.min.css"
  },
  {
    "revision": "4fdf33191102d7a24a5bf0639040d128",
    "url": "tinymce/skins/skin.mobile.min.css"
  },
  {
    "revision": "b3b3ae6828c8a28eed8b0b4cceea8f00",
    "url": "tinymce/skins/skin.shadowdom.min.css"
  }
]);