self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "341413aa00f83d2aaab2",
    "url": "css/401.dfe75472.css"
  },
  {
    "revision": "abcf05bbbb8df3c35629",
    "url": "css/404.96fe1c26.css"
  },
  {
    "revision": "cc8907b7be319f5907de",
    "url": "css/app.069d2b65.css"
  },
  {
    "revision": "3abf9be2c997af1bb147",
    "url": "css/avatar-upload.ee1933e8.css"
  },
  {
    "revision": "2f05c36348f9d31cea29",
    "url": "css/back-to-top.8466c07f.css"
  },
  {
    "revision": "22197530e053d9447d1d",
    "url": "css/bar-chart.5d212974.css"
  },
  {
    "revision": "8094e60fa78c57c9708c",
    "url": "css/chunk-commons.e9516b24.css"
  },
  {
    "revision": "e769b516e51c780e67a0",
    "url": "css/chunk-libs.dc65e09b.css"
  },
  {
    "revision": "e1cb48e132bcd3d8e25d",
    "url": "css/complex-table.9dce4b9c.css"
  },
  {
    "revision": "4e35ed73ddd0956c9774",
    "url": "css/component-mixin.01ad1c27.css"
  },
  {
    "revision": "b22cb6776842d7197311",
    "url": "css/count-to.2a30681c.css"
  },
  {
    "revision": "9af3fbc6566918478d14",
    "url": "css/dashboard.73c934fb.css"
  },
  {
    "revision": "a2cc831ae93dee694cb4",
    "url": "css/draggable-kanban.8d4fee26.css"
  },
  {
    "revision": "b6905cdccda1f2a45bde",
    "url": "css/draggable-list.568c52f6.css"
  },
  {
    "revision": "c75d8322b98350f68813",
    "url": "css/draggable-select.6bc66329.css"
  },
  {
    "revision": "6e170ab74d635dc9e514",
    "url": "css/draggable-table.57916cfd.css"
  },
  {
    "revision": "547a0eedf8a1930e1ca0",
    "url": "css/dropzone.4e115fd4.css"
  },
  {
    "revision": "2dcc49058bd980182279",
    "url": "css/dynamic-table.fa158b4d.css"
  },
  {
    "revision": "2b01e2890d73f592ac2f",
    "url": "css/error-log.3bc53b81.css"
  },
  {
    "revision": "afff65f7ef04b3dbec2a",
    "url": "css/example-create~example-edit.5eff18cb.css"
  },
  {
    "revision": "f84dfc0eb9f7bc9f5f74",
    "url": "css/example-list.e72c9368.css"
  },
  {
    "revision": "0f82fc81b7a6b0f970ad",
    "url": "css/export-excel.48569099.css"
  },
  {
    "revision": "3d752a6b0cabb08e3932",
    "url": "css/i18n-demo.037e2f6c.css"
  },
  {
    "revision": "50b3e27e1c392e98d533",
    "url": "css/icons.c63cd075.css"
  },
  {
    "revision": "360dee4482dcf0d4e232",
    "url": "css/inline-edit-table.a021f9c6.css"
  },
  {
    "revision": "32fae0815c312444c75c",
    "url": "css/json-editor.f59a90f5.css"
  },
  {
    "revision": "7e3badd467cc57d42642",
    "url": "css/line-chart.41a311d4.css"
  },
  {
    "revision": "ed38bb244a2998d950d2",
    "url": "css/login.6bfd28b3.css"
  },
  {
    "revision": "9192ce54679c751e6d24",
    "url": "css/markdown.de77ceb3.css"
  },
  {
    "revision": "610d24c9f6b35e2db430",
    "url": "css/mixed-chart.069df9ae.css"
  },
  {
    "revision": "8a6fd72aece15bb512ac",
    "url": "css/pdf-download-example.d71fc2dd.css"
  },
  {
    "revision": "ba83695f484e77e1a66c",
    "url": "css/permission-directive.88607945.css"
  },
  {
    "revision": "1f7bce7a135399d2a7ec",
    "url": "css/permission-role.b6a9bfec.css"
  },
  {
    "revision": "6c75817d89ad509325f3",
    "url": "css/profile.651b444e.css"
  },
  {
    "revision": "7665ddc9157e7972d737",
    "url": "css/split-pane.86375fe2.css"
  },
  {
    "revision": "550851242814bcd1f3fa",
    "url": "css/sticky.7ca8e979.css"
  },
  {
    "revision": "3ad0007aaf66ace7ae6c",
    "url": "css/tab.07069932.css"
  },
  {
    "revision": "eb230fc0c3ca0721f32d",
    "url": "css/theme.4119be69.css"
  },
  {
    "revision": "a865410104a86c6fdb65",
    "url": "css/tinymce.1ece0c52.css"
  },
  {
    "revision": "ee1e9bcab44eaff0f09a",
    "url": "css/upload-excel.bf17a1d6.css"
  },
  {
    "revision": "6519b7ba0b6026ddeb51",
    "url": "css/vendors~avatar-upload.eb72e0fe.css"
  },
  {
    "revision": "16127204f68fe4411551",
    "url": "css/vendors~dropzone.3435b2aa.css"
  },
  {
    "revision": "ecccee42616cc6f39a0b",
    "url": "css/vendors~guide.e57e304f.css"
  },
  {
    "revision": "70d21dbc087bf0d01931",
    "url": "css/vendors~json-editor.01a052f4.css"
  },
  {
    "revision": "adcb81c5bd74de638679",
    "url": "css/vendors~json-editor~markdown.53f73f21.css"
  },
  {
    "revision": "2f6afd545bca597e228b",
    "url": "css/vendors~markdown.87b5622f.css"
  },
  {
    "revision": "27c72091ab590fb5d1c3ef90f988ddce",
    "url": "fonts/element-icons.27c72091.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "9b70ee41d12a1cf127400d23534f7efc",
    "url": "fonts/element-icons.9b70ee41.woff"
  },
  {
    "revision": "089007e721e1f22809c0313b670a36f1",
    "url": "img/401.089007e7.gif"
  },
  {
    "revision": "0f4bc32b0f52f7cfb7d19305a6517724",
    "url": "img/404-cloud.0f4bc32b.png"
  },
  {
    "revision": "a57b6f31fa77c50f14d756711dea4158",
    "url": "img/404.a57b6f31.png"
  },
  {
    "revision": "db18abdcf982cd6df8a6ed8968b0d651",
    "url": "img/404.db18abdc.svg"
  },
  {
    "revision": "65f4922cf70b120888328195aaf773e8",
    "url": "img/back-top.65f4922c.svg"
  },
  {
    "revision": "c1385220432683df19d6ae7ab70672ba",
    "url": "img/bug.c1385220.svg"
  },
  {
    "revision": "4aceb68da588facf74b454fafdf7df62",
    "url": "img/chart.4aceb68d.svg"
  },
  {
    "revision": "1a29af96c030f4a2da55b39d2551cdfc",
    "url": "img/clipboard.1a29af96.svg"
  },
  {
    "revision": "85b95edf463e219aacc1d60d68155c70",
    "url": "img/component.85b95edf.svg"
  },
  {
    "revision": "7678c0e29bc9e3490fe5ffef6677cf86",
    "url": "img/dashboard.7678c0e2.svg"
  },
  {
    "revision": "816b20123e2a5593ff53d64fa88c1f56",
    "url": "img/documentation.816b2012.svg"
  },
  {
    "revision": "48e0ccc1f30b4781bba459ce8792fd40",
    "url": "img/drag.48e0ccc1.svg"
  },
  {
    "revision": "2f0537d00619dc9f5f8ed161f8c1b598",
    "url": "img/edit.2f0537d0.svg"
  },
  {
    "revision": "31d0c153e45d50e3e86be2309fbbf3fc",
    "url": "img/education.31d0c153.svg"
  },
  {
    "revision": "43046cb59723571a9c10f3de8e189c17",
    "url": "img/email.43046cb5.svg"
  },
  {
    "revision": "58214a86bd1e5f8d71ecc7c3f363d0a5",
    "url": "img/example.58214a86.svg"
  },
  {
    "revision": "1b7088fd651650beda31914b253582fd",
    "url": "img/excel.1b7088fd.svg"
  },
  {
    "revision": "01ba74e46bd010345453270b79ead904",
    "url": "img/exit-fullscreen.01ba74e4.svg"
  },
  {
    "revision": "5403cc4b3c6c8ada32caf745a1c89b04",
    "url": "img/eye-off.5403cc4b.svg"
  },
  {
    "revision": "297e1699ad4b5371de5ada915b260c0b",
    "url": "img/eye-on.297e1699.svg"
  },
  {
    "revision": "bf349f320024eda15a1a0f22b9c8b967",
    "url": "img/form.bf349f32.svg"
  },
  {
    "revision": "8d5abcf6c8d4c66671373e2ec5f7b3d6",
    "url": "img/fullscreen.8d5abcf6.svg"
  },
  {
    "revision": "2247295da61e283a2767d24147f2a447",
    "url": "img/guide-2.2247295d.svg"
  },
  {
    "revision": "bb687ef5c0fe92f96f2b68ca1fbb804f",
    "url": "img/guide.bb687ef5.svg"
  },
  {
    "revision": "c165db6030fac1db4f0ffdd4a0f72da9",
    "url": "img/hamburger.c165db60.svg"
  },
  {
    "revision": "e94dfd4332de5b11f639705bb5a63a8f",
    "url": "img/icon.e94dfd43.svg"
  },
  {
    "revision": "2bf66df22afaa7df986b636c61277aee",
    "url": "img/international.2bf66df2.svg"
  },
  {
    "revision": "54a2abc766782b819c7c1175509a9178",
    "url": "img/language.54a2abc7.svg"
  },
  {
    "revision": "6da50df8a05e6672728d6fecf8e0d9d1",
    "url": "img/like.6da50df8.svg"
  },
  {
    "revision": "723de9069c0e9ce2590543461ad0387d",
    "url": "img/link.723de906.svg"
  },
  {
    "revision": "c8b4d41611332e1660af6dc28a41a9a7",
    "url": "img/list.c8b4d416.svg"
  },
  {
    "revision": "017ab31003abed6c29ac3b221f3c3545",
    "url": "img/lock.017ab310.svg"
  },
  {
    "revision": "a04029acf56967b09d7dc59e27ec6b46",
    "url": "img/message.a04029ac.svg"
  },
  {
    "revision": "45bf45d58216953552fe68b4bd407913",
    "url": "img/money.45bf45d5.svg"
  },
  {
    "revision": "07001d4f9c0088f571aff39f2353b681",
    "url": "img/nested.07001d4f.svg"
  },
  {
    "revision": "74c4ccf7aabf7ef60e5037a11eb4c37e",
    "url": "img/password.74c4ccf7.svg"
  },
  {
    "revision": "9cd54e40981d97b636f447f74caf4766",
    "url": "img/pdf.9cd54e40.svg"
  },
  {
    "revision": "66b2f058c2c39a21e903f3d66332fdbf",
    "url": "img/people.66b2f058.svg"
  },
  {
    "revision": "427f2fae00c32da89ef155a0cd21a2dd",
    "url": "img/peoples.427f2fae.svg"
  },
  {
    "revision": "44496527f8cbec27908f7cb46231f7da",
    "url": "img/qq.44496527.svg"
  },
  {
    "revision": "7d1db82ac4e02f8b0f236d2fbacea636",
    "url": "img/search.7d1db82a.svg"
  },
  {
    "revision": "fee3df9014728cb5f7b1e9946781e882",
    "url": "img/shopping.fee3df90.svg"
  },
  {
    "revision": "5b470b164f8963e4a98a01329c39d7a8",
    "url": "img/size.5b470b16.svg"
  },
  {
    "revision": "5ab5ef913742d07d1c9f944e2d008342",
    "url": "img/skill.5ab5ef91.svg"
  },
  {
    "revision": "b8a4c104d25c863fd4b3dc5420c21691",
    "url": "img/star.b8a4c104.svg"
  },
  {
    "revision": "8b079badd1155538b598a207e9b50eb1",
    "url": "img/tab.8b079bad.svg"
  },
  {
    "revision": "e06c3135c840d3980830d203b0ae42b3",
    "url": "img/table.e06c3135.svg"
  },
  {
    "revision": "d686b3d799702fdd0ec0ff99182ee7de",
    "url": "img/theme.d686b3d7.svg"
  },
  {
    "revision": "f6d0f37685a52d7460f6f6b576183f09",
    "url": "img/tree-table.f6d0f376.svg"
  },
  {
    "revision": "55adbaf09d0d699520dfdc298678e104",
    "url": "img/tree.55adbaf0.svg"
  },
  {
    "revision": "831f041edc935a8ea621615e98e6d080",
    "url": "img/user.831f041e.svg"
  },
  {
    "revision": "4023301962cef2a950fa031753941037",
    "url": "img/wechat.40233019.svg"
  },
  {
    "revision": "6da3bad1fe0faffa37359106f3f8e95e",
    "url": "img/zip.6da3bad1.svg"
  },
  {
    "revision": "ed5959bae42da15eadc8c010f779e51a",
    "url": "index.html"
  },
  {
    "revision": "341413aa00f83d2aaab2",
    "url": "js/401.d3c4881f.js"
  },
  {
    "revision": "abcf05bbbb8df3c35629",
    "url": "js/404.891e85cf.js"
  },
  {
    "revision": "cc8907b7be319f5907de",
    "url": "js/app.b148be62.js"
  },
  {
    "revision": "4360efb2cbec1e903246",
    "url": "js/auth-redirect.b188cdc1.js"
  },
  {
    "revision": "3abf9be2c997af1bb147",
    "url": "js/avatar-upload.bd5a288b.js"
  },
  {
    "revision": "2f05c36348f9d31cea29",
    "url": "js/back-to-top.a08777da.js"
  },
  {
    "revision": "22197530e053d9447d1d",
    "url": "js/bar-chart.bb14f433.js"
  },
  {
    "revision": "40f0aad5922af7af6a51",
    "url": "js/chunk-27ae24c9.b25b304b.js"
  },
  {
    "revision": "c2a7c4add013cbe0be37",
    "url": "js/chunk-3a0f5d2c.928a050b.js"
  },
  {
    "revision": "0a8d80adfb7379a6dc35",
    "url": "js/chunk-566428ae.b235bb8e.js"
  },
  {
    "revision": "36204d204e8910202919",
    "url": "js/chunk-611e361e.adafd233.js"
  },
  {
    "revision": "8094e60fa78c57c9708c",
    "url": "js/chunk-commons.e8b93c4a.js"
  },
  {
    "revision": "2fd516c84481bbfaffc3",
    "url": "js/chunk-elementUI.210a4b2d.js"
  },
  {
    "revision": "e769b516e51c780e67a0",
    "url": "js/chunk-libs.144be09e.js"
  },
  {
    "revision": "38731f51ecd829eb93da",
    "url": "js/clipboard.14374c57.js"
  },
  {
    "revision": "e1cb48e132bcd3d8e25d",
    "url": "js/complex-table.fdefda47.js"
  },
  {
    "revision": "4e35ed73ddd0956c9774",
    "url": "js/component-mixin.a37604a8.js"
  },
  {
    "revision": "b22cb6776842d7197311",
    "url": "js/count-to.a2d3f86f.js"
  },
  {
    "revision": "9af3fbc6566918478d14",
    "url": "js/dashboard.d77529e7.js"
  },
  {
    "revision": "50a0bda4fa68fbd46a2c",
    "url": "js/draggable-dialog.82f36b70.js"
  },
  {
    "revision": "a2cc831ae93dee694cb4",
    "url": "js/draggable-kanban.ac96f3ec.js"
  },
  {
    "revision": "b6905cdccda1f2a45bde",
    "url": "js/draggable-list.937c62c1.js"
  },
  {
    "revision": "c75d8322b98350f68813",
    "url": "js/draggable-select.1d04a0cf.js"
  },
  {
    "revision": "6e170ab74d635dc9e514",
    "url": "js/draggable-table.3e5df991.js"
  },
  {
    "revision": "547a0eedf8a1930e1ca0",
    "url": "js/dropzone.a27df09e.js"
  },
  {
    "revision": "2dcc49058bd980182279",
    "url": "js/dynamic-table.ab294b76.js"
  },
  {
    "revision": "2b01e2890d73f592ac2f",
    "url": "js/error-log.a7c69ed2.js"
  },
  {
    "revision": "a52f64d97931d3af01fc",
    "url": "js/example-create.52b03e45.js"
  },
  {
    "revision": "afff65f7ef04b3dbec2a",
    "url": "js/example-create~example-edit.049c5c0b.js"
  },
  {
    "revision": "c86022c06a55c4689f34",
    "url": "js/example-edit.8fca9001.js"
  },
  {
    "revision": "f84dfc0eb9f7bc9f5f74",
    "url": "js/example-list.cc22655e.js"
  },
  {
    "revision": "0f82fc81b7a6b0f970ad",
    "url": "js/export-excel.e32ba39a.js"
  },
  {
    "revision": "a714ad10d2f333902854",
    "url": "js/guide.7e9dc5d5.js"
  },
  {
    "revision": "3d752a6b0cabb08e3932",
    "url": "js/i18n-demo.bae86026.js"
  },
  {
    "revision": "50b3e27e1c392e98d533",
    "url": "js/icons.84044d14.js"
  },
  {
    "revision": "360dee4482dcf0d4e232",
    "url": "js/inline-edit-table.a3f858d9.js"
  },
  {
    "revision": "32fae0815c312444c75c",
    "url": "js/json-editor.f6310320.js"
  },
  {
    "revision": "7e3badd467cc57d42642",
    "url": "js/line-chart.0a857a78.js"
  },
  {
    "revision": "ed38bb244a2998d950d2",
    "url": "js/login.9a086c08.js"
  },
  {
    "revision": "9192ce54679c751e6d24",
    "url": "js/markdown.bf08d23b.js"
  },
  {
    "revision": "e1f732a6fe1500799664",
    "url": "js/menu1-1.a42e8615.js"
  },
  {
    "revision": "50db1b30f8381d8c78a4",
    "url": "js/menu1-2-1.816e7ea9.js"
  },
  {
    "revision": "a7c92f145437c89de0a3",
    "url": "js/menu1-2-2.0fa2ad48.js"
  },
  {
    "revision": "2fe66236bbe979ccdc51",
    "url": "js/menu1-2.3c5210d8.js"
  },
  {
    "revision": "64cb2d971008fe2bb016",
    "url": "js/menu1-3.d8ca163e.js"
  },
  {
    "revision": "5e407b17290ecdfeb6bd",
    "url": "js/menu1.fa400ca8.js"
  },
  {
    "revision": "4d170c3248bf460f85fc",
    "url": "js/menu2.b065216d.js"
  },
  {
    "revision": "cd479c55fab6a0c9d762",
    "url": "js/merge-header.7e95d6ee.js"
  },
  {
    "revision": "610d24c9f6b35e2db430",
    "url": "js/mixed-chart.db8d16a9.js"
  },
  {
    "revision": "8a6fd72aece15bb512ac",
    "url": "js/pdf-download-example.b42101cc.js"
  },
  {
    "revision": "c3054a837a218a61a3d8",
    "url": "js/pdf.7a4a6d9a.js"
  },
  {
    "revision": "ba83695f484e77e1a66c",
    "url": "js/permission-directive.60587519.js"
  },
  {
    "revision": "db7f8dee55957703e741",
    "url": "js/permission-page.14d75610.js"
  },
  {
    "revision": "1f7bce7a135399d2a7ec",
    "url": "js/permission-role.759182e5.js"
  },
  {
    "revision": "6c75817d89ad509325f3",
    "url": "js/profile.d376ce05.js"
  },
  {
    "revision": "9a4fef7b9853d12c4fca",
    "url": "js/redirect.cfe70647.js"
  },
  {
    "revision": "5801a53e90a3471924b3",
    "url": "js/runtime.ac7a529c.js"
  },
  {
    "revision": "ed8c9c0072911ab4ee23",
    "url": "js/select-excel.ab3ecad5.js"
  },
  {
    "revision": "7665ddc9157e7972d737",
    "url": "js/split-pane.adb683ed.js"
  },
  {
    "revision": "550851242814bcd1f3fa",
    "url": "js/sticky.ff6d9694.js"
  },
  {
    "revision": "3ad0007aaf66ace7ae6c",
    "url": "js/tab.f59d5714.js"
  },
  {
    "revision": "eb230fc0c3ca0721f32d",
    "url": "js/theme.83415e8a.js"
  },
  {
    "revision": "a865410104a86c6fdb65",
    "url": "js/tinymce.12eaf4eb.js"
  },
  {
    "revision": "ee1e9bcab44eaff0f09a",
    "url": "js/upload-excel.3551fed4.js"
  },
  {
    "revision": "6519b7ba0b6026ddeb51",
    "url": "js/vendors~avatar-upload.2901ed92.js"
  },
  {
    "revision": "4409730597bbdcfdba74",
    "url": "js/vendors~bar-chart~dashboard~line-chart~mixed-chart.c7e61c62.js"
  },
  {
    "revision": "41df33fe4930a4f986a2",
    "url": "js/vendors~complex-table~export-excel~merge-header~select-excel.cd6ccc05.js"
  },
  {
    "revision": "dea5414c1ad48f77d876",
    "url": "js/vendors~complex-table~export-excel~merge-header~select-excel~upload-excel.bf0adb33.js"
  },
  {
    "revision": "08f05327a10cd499274f",
    "url": "js/vendors~complex-table~export-excel~merge-header~select-excel~upload-excel~zip.fdb05a70.js"
  },
  {
    "revision": "61e0b21651deb1fd3aae",
    "url": "js/vendors~complex-table~permission-role.3ee0f2a4.js"
  },
  {
    "revision": "e9901bae722ea09a6e63",
    "url": "js/vendors~draggable-kanban~draggable-list.ac28717f.js"
  },
  {
    "revision": "124a53e6462f177edfab",
    "url": "js/vendors~draggable-select~draggable-table.4c86302a.js"
  },
  {
    "revision": "16127204f68fe4411551",
    "url": "js/vendors~dropzone.9f69bafc.js"
  },
  {
    "revision": "14f69b5641a3bb76ea85",
    "url": "js/vendors~example-create~example-edit~tinymce.c0cfa6d0.js"
  },
  {
    "revision": "ecccee42616cc6f39a0b",
    "url": "js/vendors~guide.5d951731.js"
  },
  {
    "revision": "70d21dbc087bf0d01931",
    "url": "js/vendors~json-editor.c2609028.js"
  },
  {
    "revision": "adcb81c5bd74de638679",
    "url": "js/vendors~json-editor~markdown.55ddcdc2.js"
  },
  {
    "revision": "2f6afd545bca597e228b",
    "url": "js/vendors~markdown.0e138e7e.js"
  },
  {
    "revision": "386309625406546f6b28",
    "url": "js/vendors~zip.1d591a93.js"
  },
  {
    "revision": "885a61a2438d766e4098",
    "url": "js/zip.ba39949c.js"
  },
  {
    "revision": "5b1b3f3d78e7eca45f642ed55c1d5cf9",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "331afb7f9192fadaac7d785a391e39b2",
    "url": "tinymce/README.md"
  },
  {
    "revision": "917c1605513b2a31413fb4a28cf41805",
    "url": "tinymce/emojis.min.js"
  },
  {
    "revision": "833bb31f5d452f0b036f558304f7bd43",
    "url": "tinymce/langs/es.js"
  },
  {
    "revision": "2307d7e18f4d82323f8460b954366d6c",
    "url": "tinymce/langs/it.js"
  },
  {
    "revision": "c23079797eb0bbb399070c37ef52efc9",
    "url": "tinymce/langs/ja.js"
  },
  {
    "revision": "c60c7a4d77abf22380711ea8c1982bb1",
    "url": "tinymce/langs/ko_KR.js"
  },
  {
    "revision": "a561a4484a28c2267c30a4455d3da68e",
    "url": "tinymce/langs/zh_CN.js"
  },
  {
    "revision": "fa6ba7fd4905539e5b2aa845d383278b",
    "url": "tinymce/skins/content.inline.min.css"
  },
  {
    "revision": "33ccf85167a5181c2dead9c10ccfbc4b",
    "url": "tinymce/skins/content.min.css"
  },
  {
    "revision": "411c2608b6be78849a76c0ed14200234",
    "url": "tinymce/skins/content.mobile.min.css"
  },
  {
    "revision": "baecf466c40e709e7ffdbc935fc0813a",
    "url": "tinymce/skins/fonts/tinymce-mobile.woff"
  },
  {
    "revision": "87d30a0b3dd7f30d905aa5a79d64a686",
    "url": "tinymce/skins/skin.min.css"
  },
  {
    "revision": "4fdf33191102d7a24a5bf0639040d128",
    "url": "tinymce/skins/skin.mobile.min.css"
  },
  {
    "revision": "b3b3ae6828c8a28eed8b0b4cceea8f00",
    "url": "tinymce/skins/skin.shadowdom.min.css"
  }
]);